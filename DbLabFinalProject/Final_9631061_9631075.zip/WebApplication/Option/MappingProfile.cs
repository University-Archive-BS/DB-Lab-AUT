﻿using AutoMapper;

namespace AutFinalProject.Option
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            // CreateMap<Comment, CommentOutputDto>();
        }
    }
}