﻿using System;

namespace AutFinalProject.Option
{
    public class SwaggerOption
    {
        public string JsonRoute { get; set; }

        public string Description { get; set; }

        public string UIEndpoint { get; set; }
    }
}