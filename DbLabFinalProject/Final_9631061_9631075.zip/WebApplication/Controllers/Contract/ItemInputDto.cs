﻿namespace AutFinalProject.Controllers.Contract
{
    public class ItemInputDto
    {
        public long ProductId { get; set; }
        public int Count { get; set; }
    }
}